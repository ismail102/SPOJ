#include<bits/stdc++.h>
#define open()  freopen("/home/mukul/Desktop/input.txt","r",stdin);
#define show()  freopen("/home/mukul/Desktop/output.txt","w",stdout);
#define Max 100005
using namespace std;
void inout(){open();}
////Code From Here

string str[Max];
int Phi[Max];
int suffixArr[Max];
int PLCP[Max];
int LCP[Max];
string T;
int SA[Max];
int maxLCP;

struct suffix
{
    int index;
    int rank[2];
    
}suffixes[100005];
int cmp(suffix a, suffix b)
{
    return (a.rank[0] == b.rank[0])?(a.rank[1] < b.rank[1]?1:0):(a.rank[0] < b.rank[0]?1:0);

}
void buildSuffixArray(string txt,int n)
{
    for(int i=0,j=n-1;i<n;i++,j--)
    {
        suffixes[i].index = i;
        suffixes[i].rank[0] = txt[i];
        suffixes[i].rank[1] = ((i+1) <n )?(txt[i + 1]):-1;            
    }

    sort(suffixes,suffixes+n,cmp);
    int ind[n];

    for(int k = 4;k<2*n;k=k*2)
    {
            int rank = 0;
            int prev_rank = suffixes[0].rank[0];
            suffixes[0].rank[0] = rank;
            ind[suffixes[0].index] = 0; 
        
        for(int i=1;i<n;i++){
            if(suffixes[i].rank[0]==prev_rank && suffixes[i].rank[1] == suffixes[i-1].rank[1])
            {
                prev_rank = suffixes[i].rank[0];
                suffixes[i].rank[0] = rank;
            }
            else
            {
                prev_rank = suffixes[i].rank[0];
                suffixes[i].rank[0] = ++rank;
            }
            ind[suffixes[i].index] = i;
        }
        for(int i=0;i<n;i++)
        {
            int nextindex = suffixes[i].index + k/2;
            suffixes[i].rank[1] = (nextindex < n)?suffixes[ind[nextindex]].rank[0]:-1;
        }
        sort(suffixes,suffixes+n,cmp);
    }
    for(int i=0;i<n;i++)
    {
        suffixArr[i] = suffixes[i].index;
        //cout<<suffixArr[i]<<' ';
    }

    cout<<suffixArr[0]<<endl;

}

int main()
{
    //inout();
    string A;
    string str;

    cin>>A;

    //cout<<A<<endl;

    bool f=false;

    for(int i=1;i<A.size();i++){
        if(A[i]!=A[i-1]){
            f=true;
            break;
        }
    }
    if(f==false){
        cout<<0<<endl;
        return 0;
    }

    T = A;

    int n = T.size();


    buildSuffixArray(T,n);

    return 0;
}