#include<bits/stdc++.h>
#define open()  freopen("/home/mukul/Desktop/input.txt","r",stdin);
#define show()  freopen("/home/mukul/Desktop/output.txt","w",stdout);
using namespace std;
void inout(){open(); show();}
////Code From Here

string str[1000];
int Phi[1000];
int suffixArr[1000];
int PLCP[1000];
int LCP[1000];
string T;
int SA[1000];
int maxLCP;

set<string>s;

struct suffix
{
    int index;
    int rank[2];
    
}suffixes[1000];
int cmp(suffix a, suffix b)
{
    return (a.rank[0] == b.rank[0])?(a.rank[1] < b.rank[1]?1:0):(a.rank[0] < b.rank[0]?1:0);

}
void buildSuffixArray(string txt,int n)
{
    string st="",temp;
    for(int i=0,j=n-1;i<n;i++,j--)
    {
        suffixes[i].index = i;
        suffixes[i].rank[0] = txt[i];
        suffixes[i].rank[1] = ((i+1) <n )?(txt[i + 1]):-1;            
    }
    sort(suffixes,suffixes+n,cmp);
    int ind[n];
    for(int k = 4;k<2*n;k=k*2)
    {
            int rank = 0;
            int prev_rank = suffixes[0].rank[0];
            suffixes[0].rank[0] = rank;
            ind[suffixes[0].index] = 0; 
        
        for(int i=1;i<n;i++){
            if(suffixes[i].rank[0]==prev_rank && suffixes[i].rank[1] == suffixes[i-1].rank[1])
            {
                prev_rank = suffixes[i].rank[0];
                suffixes[i].rank[0] = rank;
            }
            else
            {
                prev_rank = suffixes[i].rank[0];
                suffixes[i].rank[0] = ++rank;
            }
            ind[suffixes[i].index] = i;
        }
        for(int i=0;i<n;i++)
        {
            int nextindex = suffixes[i].index + k/2;
            suffixes[i].rank[1] = (nextindex < n)?suffixes[ind[nextindex]].rank[0]:-1;
        }
        sort(suffixes,suffixes+n,cmp);
    }
    for(int i=0;i<n;i++){
        suffixArr[i] = suffixes[i].index;
    }
}
int computeLCP(int n)
{
    for(int i=0;i<n;i++) SA[i] = suffixArr[i];
    for(int i=0;i<n;i++){cout<<SA[i]<<' ';}cout<<endl;
    int i, L;
    Phi[SA[0]] = -1;
    for (i = 1; i < n; i++){
        Phi[SA[i]] = SA[i-1];
    }
    for (i = L = 0; i < n; i++){
        if (Phi[i] == -1){
            PLCP[i] = 0;
            continue;
        }
        while (T[i + L] == T[Phi[i] + L]) L++;  
        PLCP[i] = L;
        L = max(L-1, 0);   
    }
    int lcpsum = 0;

    for (i = 1; i < n; i++){
        LCP[i] = PLCP[SA[i]];
        lcpsum+=LCP[i];
    }
    int ans = (n)*(n+1)/2 - lcpsum;
// $ sign add korte hobe    
    int str_len =  n - 1;
    int ans1 = 0;
    for(int i=1;i<n;i++){
        ans1+=(str_len - SA[i] - LCP[i]);
    }
/*for(int i=0;i<n;i++) cout<<LCP[i]<<' ';cout<<endl;
 cout<<ans<<' '<<ans1<<endl;
 */
return ans;
}
int main()
{
   //inout();
    string A,txt="";
    int cas =1,t;
    cin>>t;
    while(t--){
    cin>>A;
    T = A;T+="$";
    int n = T.size();
    maxLCP = 0;
    buildSuffixArray(T,n);
    cout<<computeLCP(n)<<endl;
    }
    return 0;
}