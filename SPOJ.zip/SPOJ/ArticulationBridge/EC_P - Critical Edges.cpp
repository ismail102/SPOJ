#include<bits/stdc++.h>
using namespace std;
#define Max 1000
#define pb push_back
#define pii pair<int,int>
int disc[Max];
bool Ap[Max];
bool vis[Max];
int low[Max];
int parent[Max];
int tim;
vector<pii>critical;

vector<int>edge[Max];

struct st
{
    int u,v;
}s[Max*Max];

bool cmp(st a, st b)
{
    if(a.u<b.u) return true;
    if(a.u==b.u){
        if(a.v<b.v) return true;
        return false;
    }
    return false;
}

void dfs(int u)
{
    vis[u] = true;
    disc[u] = low[u] = (++tim);
    for(int i=0;i<edge[u].size();i++){
        int v = edge[u][i];
        if(v==parent[u]) continue;
        if(!vis[v]){
            parent[v] = u;

            dfs(v);

            low[u] = min(low[v],low[u]);

            if(low[v] > disc[u]){
                critical.pb(pii(min(u,v),max(u,v)));
            }
        }

        low[u] = min(low[u],disc[v]);
    }
}
int main()
{

    int n,m,cas=1;
    int t;
    cin>>t;
    while(t--){
        cin>>n>>m;

        for(int i=0;i<=Max;i++){
            edge[i].clear();

            Ap[i]=false;
            vis[i]=false;
            parent[i]=-1;
            low[i] = 0;
        }
        tim = 0;
        int u,v;
        for(int i=0;i<m;i++){
            cin>>u>>v;
            edge[u].pb(v);
            edge[v].pb(u);
        }

        critical.clear();

        for(int i=1;i<=n;i++){
            if(!vis[i]){
                dfs(i);
            }
        }

        for(int i=0;i<critical.size();i++){
            s[i].u = critical[i].first;
            s[i].v = critical[i].second;
        }

        sort(s,s+critical.size(),cmp);
        printf("Caso #%d\n",cas++);
        if(critical.size()==0){
            printf("Sin bloqueos\n");
            continue;
        }
        cout<<critical.size()<<endl;
        for(int i=0;i<critical.size();i++){
            cout<<s[i].u<<' '<<s[i].v<<endl;
        }

    }
    return 0;
}
