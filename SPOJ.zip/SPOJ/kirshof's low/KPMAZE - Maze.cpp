#include<bits/stdc++.h>
using namespace std;
#define Max 30
int Degree[30][30];
int Adj[30][30];
bool wall[30][30];
int ara[30][30];
int dx[]={0,0,-1,1};
int dy[]={-1,1,0,0};
int n,m;

int determinant(int f[30][30],int x)
{
  int pr,c[30],d=0,b[30][30],j,p,q,t;
  if(x==2)
  {
    d=0;
    d=(f[1][1]*f[2][2])-(f[1][2]*f[2][1]);
    return(d);
   }
  else
  {
    for(j=1;j<=x;j++)
    {
      int r=1,s=1;
      for(p=1;p<=x;p++)
        {
          for(q=1;q<=x;q++)
            {
              if(p!=1&&q!=j)
              {
                b[r][s]=f[p][q];
                s++;
                if(s>x-1)
                 {
                   r++;
                   s=1;
                  }
               }
             }
         }
     for(t=1,pr=1;t<=(1+j);t++)
     pr=(-1)*pr;
     c[j]=pr*determinant(b,x-1);
     }
     for(j=1,d=0;j<=x;j++)
     {
       d=d+(f[1][j]*c[j]);
      }
     return(d);
}
}

int main()
{
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        memset(Degree,0,sizeof(Degree));
        memset(Adj,0,sizeof(Adj));
        int k;
        scanf("%d",&k);
        int r1[30],r2[30],c1[30],c2[30];
        for(int i=0;i<k;i++){
            scanf("%d%d%d%d",&r1[i],&c1[i],&r2[i],&c2[i]);

        }

        int c=1;
        for(int  i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                ara[i][j]=c++;
            }
        }
        memset(wall,false,sizeof(wall));
       // memset(vis,false,sizeof(vis));

        for(int i=0;i<k;i++){
            wall[ara[r1[i]][c1[i]]][ara[r2[i]][c2[i]]]=true;
            wall[ara[r2[i]][c2[i]]][ara[r1[i]][c1[i]]]=true;

            //cout<<ara[r1[i]][c1[i]]<<' '<<ara[r2[i]][c2[i]]<<endl;
        }

        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                for(int l=0;l<4;l++){
                    int tx = dx[l] + i;
                    int ty = dy[l] + j;
                    if(tx>0 and tx<=n and ty>0 and ty<=m and wall[ara[i][j]][ara[tx][ty]]==false){
                         Degree[ara[i][j]][ara[i][j]]++;
                        Adj[ara[tx][ty]][ara[i][j]]=1;
                        Adj[ara[i][j]][ara[tx][ty]]=1;
                    }
                }
            }
        }


        //dfs(0,0);

       /* for(int i=0;i<n*m;i++){
            for(int j=0;j<n*m;j++){
                cout<<Adj[i][j]<<' ';
            }
            cout<<endl;
        }*/
/*
        for(int i=0;i<n*m;i++){
            for(int j=0;j<n*m;j++){
                cout<<Degree[i][j]<<' ';
            }
            cout<<endl;
        }
*/
        int mat[30][30];

       for(int i=0;i<n*m;i++){
            for(int j=0;j<n*m;j++){
                mat[i][j]=(Degree[i][j] - Adj[i][j]);
               // cout<<mat[i][j]<<' ';
            }
            //cout<<endl;
        }
        int N=n*m;
        printf("%d\n",determinant(mat,N-1));
    }
    return 0;
}

