#include<bits/stdc++.h>
using namespace std;

#define Max 100005
int An[Max][20];
int ara[Max];
int Ans[Max];
int vis[Max];
int value[Max];
int aa[Max];
int L[Max];
int nodeId[Max];
int st[Max],en[Max];
vector<int>edge[Max];
int pos;
int BLOCK;
void dfs(int f,int u,int d)
{
    An[u][0] = f;
    L[u] = d;
    ++pos;
    st[u] = pos;
    nodeId[pos] = u;
    for(int i=0;i<edge[u].size();i++){
        int v = edge[u][i];
        if(v!=f){
            dfs(u,v,d+1);
        }
    }

    ++pos;
    en[u] = pos;
    nodeId[pos] = u;
    //cout<<nodeId[pos]<<endl;

}

void sparsetable(int n)
{

    for(int j=1;(1<<j) < n; j++){
        for(int i=0;i<n;i++){
            if(An[i][j-1]!=-1){
                An[i][j] = An[An[i][j-1]][j-1];
            }
        }
    }
}

int LCA(int p,int q)
{
    if(L[p] < L[q]) swap(p,q);

    int log=1;
    while(1){
        int next = log+1;
        if((1<<next) > L[p]) break;
        log++;
    }

    for(int i=log;i>=0;i--){
        if(L[p] - (1<<i) >=L[q] ){
            p = An[p][i];
        }
    }
    if(p==q) return p;

    for(int i=log;i>=0;i--){
        if(An[p][i]!=-1 and An[p][i] != An[q][i]){
            p = An[p][i];
            q = An[q][i];
        }
    }
    return An[p][0];
}

struct node{
    int L,R,lca,idx;

}Q[Max];

bool cmp(node x, node y){
    if(x.L/BLOCK != y.L/BLOCK){
        return x.L/BLOCK < y.L/BLOCK;
    }
    return x.R < y.R;
}
void check(int x,int& cnt)
{
    //cout<<x+1<<',';
    if(vis[x] and (--value[ara[x]]==0)) cnt--;
    else if(!vis[x] and (value[ara[x]]++ == 0)) cnt++;

    vis[x]^=1;
}
int main()
{
    //freopen("input.txt", "r",stdin);
    int t;
    int n,m;
    while(scanf("%d%d",&n,&m)!=EOF)
    {
        memset(vis,0,sizeof(vis));
        memset(value,0,sizeof(value));

        memset(An,-1,sizeof(An));

        for(int i=0;i<=n;i++){
            edge[i].clear();
        }
        for(int i=0;i<n;i++){
            scanf("%d",&ara[i]);
            aa[i]=ara[i];
        }

        sort(aa,aa+n);

        int k = unique(aa,aa+n) - aa - 1;

        for(int i=0;i<n;i++){
            ara[i] = lower_bound(aa,aa+k,ara[i]) - aa;
        }

        /*for(int i=0;i<n;i++) cout<<ara[i]<<' ';
        cout<<endl;*/
        int u,v;
        for(int i=1;i<n;i++){
            scanf("%d%d",&u,&v);
            u--,v--;
            edge[u].push_back(v);
            edge[v].push_back(u);
        }
        pos = 0;
        An[0][0]=-1;
        dfs(-1,0,0);
        sparsetable(n);
        /*
        for(int i=1;i<=pos;i++){
            cout<<nodeId[i]<<' ';
        }
        cout<<endl;*/

        for(int i=0;i<m;i++)
        {
            scanf("%d%d",&u,&v);
            u--,v--;
            Q[i].lca = LCA(u,v);

            //cout<<u+1<<"==>"<<v+1<<' '<<"lca = "<<Q[i].lca+1<<endl;

            if(st[u] > st[v]) swap(u,v);

            if(Q[i].lca == u){
                Q[i].L = st[u];
                Q[i].R = st[v];
            }
            else{
                Q[i].L = en[u];
                Q[i].R = st[v];
            }
            Q[i].idx = i;

        }

        BLOCK = sqrt(n);

        sort(Q,Q+m,cmp);



        int curL=0,curR=0,cnt=0;

        for(int i=0;i<m;i++){

            int L = Q[i].L,R = Q[i].R;

            //cout<<"u = "<<nodeId[L]+1<<' '<<"v = "<<nodeId[R]+1<<endl;
            //cout<<"L ="<<L<<' '<<"R = "<<R<<endl;

            //cout<<"( ";
            while(curL < L){
                check(nodeId[curL],cnt);
                curL++;
            }
            while(curL > L){
                check(nodeId[curL-1],cnt);
                curL--;
            }
            while(curR <= R ){
                check(nodeId[curR],cnt);
                curR++;
            }
            while(curR > R+1){
                check(nodeId[curR-1],cnt);
                curR--;
            }
            //cout<<" )\n";
          //  cout<<"curL = "<<curL<<' '<<"curR = "<<curR<<endl;
            int u = nodeId[curL];
            int v = nodeId[curR];
            if(Q[i].lca != u and Q[i].lca != v) check(Q[i].lca,cnt);
            Ans[Q[i].idx] = cnt;
            if(Q[i].lca !=u and Q[i].lca != v) check(Q[i].lca,cnt);
        }
        //cout<<endl;
        for(int i=0;i<m;i++){
            printf("%d\n",Ans[i]);
        }
    }

}
