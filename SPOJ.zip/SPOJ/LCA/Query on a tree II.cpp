#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define ll long long
int L[Max];
ll dis[Max];
bool vis[Max];
int prnt[Max];
int An[Max][25];
int nd = 0;
vector<int>edge[Max],cost[Max],aa,bb;
void dfs(int f,int u,ll d,int level)
{
    L[u] = level;
    dis[u]=d;
    prnt[u]=f;
    vis[u]=true;
    for(int i=0;i<edge[u].size();i++){
        int v = edge[u][i];
        if(!vis[v]){
            dfs(u,v,d+cost[u][i],level+1);
        }
    }
}
void sparstable(int n)
{
    memset(An,-1,sizeof(An));
    prnt[0] = -1;
    for(int i=0;i<n;i++) An[i][0] = prnt[i];

    for(int j=1; (1<<j) <n; j++){
        for(int i=0;i<n;i++){
            if(An[i][j-1]!=-1){
                An[i][j] = An[An[i][j-1]][j-1];
            }
        }
    }
}
int LCA(int p,int q)
{
    int x=p,y=q;
    int log;

    if(L[p]<L[q]) swap(p,q);

    log = 1;
    while(1){
        int next = log + 1;
        if( (1<<next) > L[p] ) break;
        log++;
    }

    int f=0;

    for(int i = log;i>=0;i--){

        if(L[p] - (1<<i) >= L[q]){
            p = An[p][i];
            //f=1;
        }
    }
    if(p==q) return p;

    for(int i = log;i>=0;i--){
        if(An[p][i]!=-1 and An[p][i]!=An[q][i]){
            p = An[p][i];
            q = An[q][i];
        }
    }
    

    return prnt[p];

}
int kth(int p,int q,int nd)
{
    int a = LCA(p,q);

    if(L[p]-L[a]+1<nd){
        nd -= (L[p] - L[a]+1);
        swap(p,q);
    }
    else{
        nd = (L[p] - L[a]+1 - nd);
    }

    nd = L[a] + nd;

    int log = 1;
    while(1){
        int next = log+1;
        if((1<<next) > L[p]) break;
        log++;
    }

    for(int i = log; i>=0; i--){
        if(L[p] - (1<<i) >= nd){
            p = An[p][i];
        }
    }

    return p;
}

int main()
{
    int n,t;
    string str;
    scanf("%d",&t);
    while(t--){

        memset(L,0,sizeof(L));
        memset(vis,false,sizeof(vis));
        memset(dis,0,sizeof(dis));
        scanf("%d",&n);

        for(int i=0;i<=n;i++){
            edge[i].clear();
            cost[i].clear();
        }
        int u,v,c;
        for(int i=0;i<n-1;i++){
            scanf("%d%d%d",&u,&v,&c);
            u--,v--;
            edge[u].push_back(v);
            edge[v].push_back(u);
            cost[u].push_back(c);
            cost[v].push_back(c); 
        }
        dfs(-1,0,0,0);
        sparstable(n);
        int nd;
        while(1){
            cin>>str;
            if(str=="DONE") break;
            cin>>u>>v;
            u--,v--;

            if(str=="DIST"){
                int ans = LCA(u,v);
                //cout<<dis[u]<<' '<<dis[v]<<endl;
                cout<<dis[u]+dis[v] - 2*dis[ans]<<endl;
            }
            else{
                cin>>nd;
                int ans = kth(u,v,nd);
                cout<<ans+1<<endl;
            }
        }
    }
    return 0;
}