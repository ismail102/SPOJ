#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define pb push_back
#define mem(a,b) memset(a,b,sizeof(a))
#define ll long long
#define ull unsigned long long
vector<int>edge[Max];
int prnt[Max];
int L[Max];
int An[Max][25];
void dfs(int f,int u,int d)
{
    prnt[u] = f;

    L[u] = d;

    for(int i=0;i<edge[u].size();i++){

        int v = edge[u][i];
        if(v==f) continue;
        dfs(u,v,d+1);
    }
}

void sparstable(int n)
{
    memset(An,-1,sizeof(An));
    prnt[0] = -1;
    for(int i=0;i<n;i++) An[i][0] = prnt[i];

    for(int j=1;(1<<j) < n; j++){
        for(int i=0;i<n;i++){

            if(An[i][j-1] != -1){

                An[i][j] = An[An[i][j-1]][j-1];
                //cout<<i<<' '<<j<<' '<<An[i][j-1]<<' '<<An[An[i][j-1]][j-1]<<endl;
            }

        }

    }

}
int LCA(int p,int q)
{

    //cout<<L[p]<<' '<<L[q]<<endl;
    int log;

    if(L[p] < L[q]) swap(p,q);

    log = 1;
    while(1){
        int next = log + 1;
        if((1<<next) > L[p]) break;
        log++;
    }

   // if(p==q) return p;

    //cout<<log<<' '<<p<<' '<<L[p]<<' '<<q<<endl;
    for(int i=log;i>=0;i--){

        if(L[p] - (1<<i) >= L[q]){
        p = An[p][i];
        //cout<<"p = "<<p<<endl;
        }
    }

    //cout<<p<<' '<<q<<endl;
    if(p==q) return p;

    for(int i=log; i>=0; i--){
        if(An[p][i] != -1 and An[p][i] != An[q][i]){
            p = An[p][i];
            q = An[q][i];
        }
    }

    return prnt[p];

}
int main()
{
    int t,cas=1;
    scanf("%d",&t);
    while(t--){
        int n,m;
        int u,v;
        scanf("%d",&n);
        for(int i=0;i<=n;i++) {
            edge[i].clear();

        }
        for(int i=0;i<n;i++){
            u = i;
            scanf("%d",&m);
            for(int j=0;j<m;j++){
                scanf("%d",&v);
                v--;
                prnt[v]=u;
                edge[u].pb(v);
            }

        }
        dfs(-1,0,0);
        sparstable(n);
        int q;
        scanf("%d",&q);
        printf("Case %d:\n",cas++);
        for(int i=0;i<q;i++){
            scanf("%d%d",&u,&v);
            u--,v--;
            int ans = LCA(u,v);
            printf("%d\n",ans+1);
        }
    }
    return 0;
}
