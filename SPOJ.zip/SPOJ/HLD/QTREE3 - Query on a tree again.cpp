#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define ll long long
#define pb push_back
int chainHead[Max];
int posInBase[Max];
int posInNode[Max];
int chainIdx[Max];
int baseArray[Max];
int subsize[Max];
int tree[3*Max];
int An[Max][20];
vector<int>edge[Max];
int chainNo,pos;

void dfs(int f,int u)
{
        An[u][0] = f;
       subsize[u] = 1;
       for(int i=0;i<edge[u].size();i++){
                int v = edge[u][i];
                if(v!=f){
                    dfs(u,v);
                    subsize[u]+=subsize[v];
                }
       }
}
void HLD(int  curNode, int f)
{
        if(chainHead[chainNo]==-1){
                chainHead[chainNo]=curNode;
        }
     //   cout<<curNode<<"<===>"<<chainNo<<endl;
        chainIdx[curNode] = chainNo;
        ++pos;
        posInBase[curNode] = pos;
        baseArray[pos] = 0;
        posInNode[pos] = curNode;

        int sc = -1 , maxsize=-1;
        for(int i=0;i<edge[curNode].size();i++){

                int v = edge[curNode][i];
                if(f!=v and maxsize<subsize[v]){
                    maxsize = subsize[v];
                    sc = v;
                }
        }

        if(sc!=-1){
            HLD(sc, curNode);
        }

        for(int i=0;i<edge[curNode].size();i++){
                int v = edge[curNode][i];
             if(sc!=v and f!=v){
                ++chainNo;
                HLD(v, curNode);
             }
        }
}
void Update(int node,int s,int e, int i)
{
    if(s>i or e<i) return;
    if(s==e and e==i){
        if(tree[node]==-1)  tree[node] = posInNode[i];
        else tree[node] = -1;
        return;
    }

    int mid = (s+e)/2;
    int left = node<<1;
    int right = left+1;

    Update(left, s, mid, i);
    Update(right, mid+1, e, i);
   if(tree[left]==-1) tree[node]=tree[right];
   else tree[node]=tree[left];
}
int Query(int node, int s, int e, int i, int j){

    if(s>j or e<i) return -1;
    if(s>=i and e<=j){
        return  tree[node];
    }

    int mid = (s+e)/2;
    int left = node<<1;
    int right = left+1;
    int a = -1;
    a = Query(left, s, mid, i, j);
    if(a==-1) a = Query(right, mid+1, e, i, j);
    return a;
}
int query_up(int v,int u)
{
//cout<<u<<' '<<v<<endl;
    int uchain = chainIdx[u];
    int vchain = chainIdx[v];

    int node = -1;
    while(1){
        //cout<<uchain<<"==>"<<vchain<<endl;
        if(uchain==vchain){
            //   cout<<posInBase[v]<<' '<<posInBase[u]<<endl;
            int idx = Query(1,1,pos,posInBase[v],posInBase[u]);
           // cout<<"idx ="<<idx<<endl;
            if(idx!=-1) node = idx;
            break;
        }
        else{
            int head = chainHead[uchain];
            int idx= Query(1,1,pos,posInBase[head],posInBase[u]);
            if(idx!=-1) node = idx;
            u = An[head][0];
            uchain = chainIdx[u];
        }

    }

    return node;
}
int main()
{
    int t;
    int n,q;
    while(scanf("%d%d",&n,&q)==2){
        int u,v;
        for(int i=0;i<=n;i++) {
            edge[i].clear();
            chainHead[i]=-1;
            }
        for(int i=1;i<n;i++){
            scanf("%d%d",&u,&v);
            edge[u].pb(v);
            edge[v].pb(u);
        }

        An[1][0] = -1;
        pos=0;
        chainNo=1;
        dfs(-1,1);
        HLD(1,-1);

        for(int i=0;i<=3*Max;i++) tree[i]=-1;

        for(int i=0;i<q;i++){
            scanf("%d%d",&u,&v);
            //cout<<u<<v<<endl;
            if(u==0){
           //cout<<"pos= "<<posInBase[v]<<endl;
                Update(1,1,pos,posInBase[v]);
            }
            else{
                int ans = query_up(1,v);
                printf("%d\n",ans);
            }
        }
    }
    return 0;
}
