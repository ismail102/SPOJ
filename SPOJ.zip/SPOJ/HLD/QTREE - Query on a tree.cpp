#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define ll long long
#define pb push_back
int chainHead[Max];
int posInBase[Max];
int chainIdx[Max];
int baseArray[Max];
int weight[Max];
int nodee[Max];
int An[Max][25];
int L[Max];
int subsize[Max];
int tree[3*Max];
int edgeEnd[Max];
vector<int>edge[Max],cost[Max],idxx[Max];
int chainNo,pos;
void dfs(int f,int u,int d,int w)
{
    L[u] = d;
    subsize[u] = 1;
    An[u][0] = f;
    weight[u] = w;


    for(int i=0;i<edge[u].size();i++){
        int v = edge[u][i];
        int vcost = cost[u][i];
        int edgeNo = idxx[u][i];
        if(v!=f){
            edgeEnd[edgeNo] = v;
            dfs(u,v,d+1,vcost);
            subsize[u]+=subsize[v];
        }
    }
}
void HLD(int curNode,int w,int f)
{
    //cout<<chainNo<<' '<<chainHead[chainNo]<<' '<<curNode<<endl;
    if(chainHead[chainNo]==-1){
        chainHead[chainNo]=curNode;
    }
    chainIdx[curNode] = chainNo;
    ++pos;
    //cout<<"CurNode = "<<curNode<<' '<<"pos = "<<pos<<endl;
    posInBase[curNode] = pos;
    baseArray[pos] = weight[curNode];

    nodee[pos] = curNode;

    int sc=-1,maxsize=-1,mxcost=0;
    for(int i = 0;i<edge[curNode].size();i++){
        int v = edge[curNode][i];
        int vcost = cost[curNode][i];
        if(f!=v and maxsize<subsize[v]){
            sc = v;
            maxsize=subsize[v];
            mxcost = vcost;
        }
    }

    if(sc!=-1){
        HLD(sc,mxcost,curNode);
    }

    for(int i=0;i<edge[curNode].size();i++){
        int v = edge[curNode][i];
        int vcost = cost[curNode][i];
        if(v!=f and sc!=v){
            ++chainNo;
            HLD(v,vcost,curNode);
        }
    }
}
void sparsetable(int n)
{
    for(int j=1;(1<<j) < n;j++){
        for(int i=0;i<n;i++){
            if(An[i][j-1]!=-1){
                An[i][j]=An[An[i][j-1]][j-1];
            }
        }
    }
}

int LCA(int p,int q){
    
    if(L[p]<L[q]) swap(p,q);

    int log=1;
    while(1){
        int next=log+1;
        if((1<<next) > L[p])break;
        log++;
    }

    for(int i=log;i>=0;i--){
        if(L[p] - (1<<i) >= L[q]){
            p = An[p][i];
        }
    }
    if(p==q) return p;

    for(int i=log;i>=0;i--){
        if(An[p][i]!=-1 and An[p][i]!=An[q][i]){
            p = An[p][i];
            q = An[q][i];
        }
    }

    return An[p][0];
}

void Make_tree(int node,int s,int e)
{
    if(s==e){
        tree[node] = baseArray[s];
        return;
    }

    int mid = (s+e)/2;
    int left = node<<1;
    int right = left+1; 
    Make_tree(left,s,mid);
    Make_tree(right,mid+1,e);

    tree[node] = max(tree[left],tree[right]);
}
void Update(int node,int s,int e,int i,int v)
{
    if(s>i or e<i) return;
    if(s==i and e==i){
        tree[node] = v;
        return;
    }

    int mid = (s+e)/2;
    int left = node<<1;
    int right = left+1; 
    Update(left,s,mid,i,v);
    Update(right,mid+1,e,i,v);

    tree[node] = max(tree[left],tree[right]);
}
int query_tree(int node,int s,int e,int i,int j)
{
    if(s>j or e<i) return -1;
    if(s>=i and e<=j) return tree[node];

    int mid = (s+e)/2;
    int left = node<<1;
    int right = left+1;
    int l = query_tree(left,s,mid,i,j);
    int r = query_tree(right,mid+1,e,i,j);

    if(l==-1) return r;
    if(r==-1) return l;
    return max(l,r);
}
int query_up(int lca,int u)
{
    int uchain = chainIdx[u];
    int vchain = chainIdx[lca];
    int maxans=-1;
    Update(1,1,pos,posInBase[lca],-1);
    while(1){

        if(uchain==vchain){

            int ans = query_tree(1,1,pos,posInBase[lca],posInBase[u]);
            maxans = max(maxans,ans);
            break;
        }
        else{
            //cout<<u<<' '<<chainIdx[u]<<' '<<endl;
            int head = chainHead[uchain];
           // cout<<"head ="<<head<<' '<<"u ="<<u<<endl;
           // cout<<"headpos = "<<posInBase[head]<<' '<<"upos = "<<posInBase[u]<<endl;
            int ans = query_tree(1,1,pos,posInBase[head],posInBase[u]);
            maxans = max(maxans,ans);
            u = An[head][0];
            uchain = chainIdx[u];
        }
    }
    return maxans;
}
int query(int u,int v){

    int lca = LCA(u,v);
     int aa = query_tree(1,1,pos,posInBase[lca],posInBase[lca]);
    int ans = query_up(lca,u);
    int temp = query_up(lca,v);
   Update(1,1,pos,posInBase[lca],aa);

    return max(ans,temp);
}
int main()
{
    int t;
    scanf("%d",&t);
    while(t--){
        int n;
        scanf("%d",&n);
        int u,v,w;

        for(int i=0;i<=n;i++){
            edge[i].clear();
            cost[i].clear();
            idxx[i].clear();
            chainHead[i]=-1;
            subsize[i]=0;
        }
        for(int i=1;i<n;i++){
            scanf("%d%d%d",&u,&v,&w);
            u--,v--;
            edge[u].pb(v);
            edge[v].pb(u);
            cost[u].pb(w);
            cost[v].pb(w);
            idxx[u].pb(i);
            idxx[v].pb(i);
        }
        memset(An,-1,sizeof(An));

        An[0][0] = -1;
        pos=0;
        chainNo=1;
        dfs(-1,0,0,-1);
        HLD(0,-1,-1);
        Make_tree(1,1,pos);
        sparsetable(n);
       /* cout<<"pos = "<<pos<<endl;
        for(int i=1;i<=pos;i++) cout<<i<<' ';
        cout<<endl;
        for(int i=1;i<=pos;i++) cout<<baseArray[i]<<' ';
        cout<<endl;
        for(int i=1;i<=pos;i++) cout<<nodee[i]<<' ';
        cout<<endl;
        for(int i=1;i<=pos;i++) cout<<chainIdx[nodee[i]]<<' ';
        cout<<endl;*/

        char str[20];
        while(1){
            scanf("%s",str);
            if(str[0]=='D')break;
            scanf("%d%d",&u,&v);
           
            int ans = 0;
            if(str[0]=='Q'){
                 u--,v--;
                if(u==v) ans = 0;
                else ans = query(u,v);
                printf("%d\n",ans);
            }
            else{
                Update(1,1,pos,posInBase[edgeEnd[u]],v);
            }

        }
    }
    return 0;
}