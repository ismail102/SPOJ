#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define pb push_back

vector<int>edge[Max];
int An[Max][20];
int discv[Max];
int low[Max];
bool vis[Max];
bool Ap[Max];
int tim;
int L[Max];
int parent[Max];
void setvalue()
{
    for(int i=0;i<=Max;i++){
        
        vis[i] = Ap[i] = false;
        low[i] = 0;
        parent[i] = -1;

        edge[i].clear();

    }
    tim = 0;
}

void dfs(int u,int d,int predge)
{
    L[u] = d;

    vis[u]=true;

    discv[u]=low[u]=(++tim);

    int child = 0;

    for(int i=0; i< edge[u].size(); i++){

        int v = edge[u][i];

        if(v==parent[u]) continue;

        if(!vis[v]){

            parent[v] = u;

            An[v][0]=u;
            
            ++edg;

            if(predge != -1){
                adj[predge].pb(edg);
                adj[edg].pb(predge);
            }
            
            save[v] = edg;

            child++;

            dfs(v,d+1,edg);

            low[u] = min( low[u], low[v] );

            if(parent[u] != -1 and low[v] >=  discv[u]){
                Ap[u] = true;
            }
            
            if(parent[u] == -1 and child > 1){
                Ap[u] = true;
            }
        }

        else{

            ++edg;

            adj[edg].pb(save[v]);
            adj[save[v]].pb(edg);

        }

        low[u] = min( low[u], discv[v]);
    }
}


void sparsetable(int n)
{

    for(int j=1;(1<<j) < n; j++){
        for(int i=0;i<n;i++){
            if(An[i][j-1]!=-1){
                An[i][j] = An[An[i][j-1]][j-1];
            }
        }
    }
}

int LCA(int p,int q)
{
    if(L[p] < L[q]) swap(p,q);

    int log=1;
    while(1){
        int next = log+1;
        if((1<<next) > L[p]) break;
        log++;
    }

    for(int i=log;i>=0;i--){
        if(L[p] - (1<<i) >=L[q] ){
            p = An[p][i];
        }
    }
    if(p==q) return p;

    for(int i=log;i>=0;i--){
        if(An[p][i]!=-1 and An[p][i] != An[q][i]){
            p = An[p][i];
            q = An[q][i];
        }
    }
    return An[p][0];
}


int main()
{

    freopen("input.txt","r",stdin);

    int t;
    int n,m;
    int cas = 1;
    while(cin>>n>>m)
    {
        setvalue();

        int u,v;

        for(int i=0;i<m;i++){
            cin>>u>>v;
            u--;
            v--;

            edge[u].pb(v);
            edge[v].pb(u);

        }

        for(int i=0;i<n;i++){
            if(!vis[i]){

                dfs(i,0,-1);
            }
        }

        sparsetable(n);

        int q;

        for(int i=0;i<n;i++){
            if(Ap[i]){
                cout<<i+1<<' ';
            }
        }
        cout<<endl;

        cin>>q;

        int idx,del;

        for(int i=0;i<q;i++){

            cin>>idx>>u>>v>>del;
            u--;
            v--;
            del--;
            cout<<LCA(u,v)+1<<endl;
            cout<<LCA(u,del)+1<<endl;
            cout<<LCA(v,del)+1<<endl;

        }





    }

    
}