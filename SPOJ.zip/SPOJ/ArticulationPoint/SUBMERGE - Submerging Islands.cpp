#include<bits/stdc++.h>
using namespace std;
#define Max 100005
#define pb push_back

bool Ap[Max];

bool vis[Max];

int low[Max];

int parent[Max];

int discv[Max];

vector<int>edge[Max];

int tim = 0;

void setvalue()
{
    for(int i=0;i<=Max;i++){


        discv[i]=low[i]=0;

        vis[i]=Ap[i]=false;

        parent[i] = -1;

        edge[i].clear();

    }
    tim = 0;
}


void dfs(int u)
{
    vis[u]=true;

    discv[u] = low[u] = (++tim);

    int child = 0;

    for(int i=0;i<edge[u].size();i++){

        int v = edge[u][i];
        
        if(v==parent[u]) continue;
        
        if(!vis[v]){

            child++;
            parent[v] = u;

            dfs(v);

            low[u] = min( low[u], low[v] );

            if(parent[u] != -1 and low[v] >= discv[u]){
                Ap[u] = true;
            }

            if(parent[u] == -1 and child>1){
                Ap[u] = true;
            }

        }

        low[u] = min( low[u], discv[v] );
    }
}
int main()
{
    int n,m;
    while(cin>>n>>m)
    {
        if(n==0 and m==0) return  0;

        setvalue();

        int u,v;
        for(int i=0;i<m;i++){
            cin>>u>>v;
            u--;
            v--;
            edge[u].pb(v);
            edge[v].pb(u);
        }

        for(int i=0;i<n;i++){
            if(!vis[i]){
                dfs(i);
            }
        }   

        int cnt=0;

        for(int i=0;i<n;i++){
            if(Ap[i]) cnt++;
        }

        cout<<cnt<<endl;
    }

    return 0;
}