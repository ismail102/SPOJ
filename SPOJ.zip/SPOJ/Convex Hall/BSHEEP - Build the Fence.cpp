#include<bits/stdc++.h>
using namespace std;
#define PI acos(-1)
#define ll long long
#define Max 100005
struct Point{
  ll x,y;
  ll idx;
}P[Max],CH[Max],pp;
ll dist(Point a,Point b)
{
    return (a.x - b.x)*(a.x - b.x) + (a.y - b.y)*(a.y - b.y);
}
ll cross(Point a,Point o,Point b)
{
    return (a.x - o.x)*(b.y - o.y) - (a.y - o.y)*(b.x - o.x);
}
bool compare_position(Point a,Point b)
{
    return (a.y<b.y) or (a.y==b.y and a.x<b.x);
}
bool compare_angle(Point a,Point b)
{
    ll c = cross(pp,a,b);
    return (c>0) or (c==0 and dist(pp, a) < dist(pp,b)) or (c==0 and dist(pp,a)==dist(pp,b) and a.idx>b.idx);
}
int Graham_scan(int n)
{
    swap(P[0],*min_element(P,P+n,compare_position));
    pp = P[0];
    sort(P+1,P+n,compare_angle);
    P[n]=P[0];
/*

    for(int i=0;i<=n;i++){
        cout<<P[i].x<<' '<<P[i].y<<"=="<<P[i].idx<<endl;
    }
    cout<<endl;
    cout<<endl;*/

    int j=0;
    for(int i=0;i<=n;i++){
        while(j>=2 and cross(CH[j-2],CH[j-1],P[i]) <= 0) j--;
        CH[j++] = P[i];
    }
    return j;
}
int main()
{
    #ifndef ONLINE_JUDGE
        freopen("input.txt","r",stdin);
        //freopen("output.txt","w",stdout);
    #endif // ONLINE_JUDGE
    int n,t,cas=1;
    scanf("%d",&t);
    while(t--){
        scanf("%d",&n);
        for(int i=0;i<n;i++){
            scanf("%lld %lld", &P[i].x,&P[i].y);
            P[i].idx = (ll)(i+1);
        }
        int np = Graham_scan(n);
        double circumference = 0.0;
        /*
        cout<<"NP = "<<np-1<<endl;
        for(int i=0;i<np;i++){
            printf("%lld , %lld\n",CH[i].x,CH[i].y);
        }
        cout<<endl;
        */

        for(int i=1;i<np;i++){
            circumference+=sqrt(dist(CH[i-1],CH[i]));
        }
        bool f=false;
        if(circumference == 0.0 and np < 3)
        {
            P[n]=P[0];
            for(int i=1;i<=n;i++){
                circumference+=sqrt(dist(P[i-1],P[i]));
            }
            f = true;
        }

        if(cas++>1) printf("\n");

        printf("%.2lf\n",circumference);

        if(f==true){
            if(P[0].idx != P[n-1].idx) printf("%lld %lld\n",P[0].idx,P[n-1].idx);
            else printf("%lld\n",P[0].idx);
        }
        else{

            for(int i=np-1;i>0;i--){
                if(i==np-1){
                    printf("%lld",CH[i].idx);
                }
                else{
                    printf(" %lld",CH[i].idx);
                }
            }
            printf("\n");
        }
    }

    return 0;
}
